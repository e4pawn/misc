package com.rs.rs1.cucumber;

import com.rs.rs1.IntegrationTest;
import io.cucumber.junit.platform.engine.Cucumber;

@Cucumber
@IntegrationTest
class CucumberIT {}
