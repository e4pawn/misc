/**
 * Domain objects.
 */
package com.rs.rs1.domain;
