/**
 * Application security utilities.
 */
package com.rs.rs1.security;
