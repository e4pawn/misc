/**
 * Logging aspect.
 */
package com.rs.rs1.aop.logging;
