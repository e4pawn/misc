/**
 * Application configuration.
 */
package com.rs.rs1.config;
