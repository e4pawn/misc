/**
 * Rest layer error handling.
 */
package com.rs.rs1.web.rest.errors;
