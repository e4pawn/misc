/**
 * Application management.
 */
package com.rs.rs1.management;
